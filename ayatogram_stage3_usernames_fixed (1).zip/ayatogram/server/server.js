import http from "node:http";
import fs from "node:fs";
import path from "node:path";
import { randomBytes, randomInt, createHmac, timingSafeEqual } from "node:crypto";
import { WebSocketServer } from "ws";

const PORT = Number(process.env.PORT || 8080);
const DATA_DIR = process.env.DATA_DIR || "./data";
const USERS_FILE = path.join(DATA_DIR, "users.json");
const CHATS_FILE = path.join(DATA_DIR, "chats.json");
const MESSAGES_FILE = path.join(DATA_DIR, "messages.json");
const JWT_SECRET = process.env.JWT_SECRET || "CHANGE_THIS_DEV_SECRET_BEFORE_DEPLOYMENT";
const isProduction = process.env.NODE_ENV === "production";
fs.mkdirSync(DATA_DIR, { recursive: true });
for (const f of [USERS_FILE, CHATS_FILE, MESSAGES_FILE]) if (!fs.existsSync(f)) fs.writeFileSync(f, "[]");

function read(file) { try { return JSON.parse(fs.readFileSync(file, "utf8")); } catch { return []; } }
function write(file, data) { const tmp=file+".tmp"; fs.writeFileSync(tmp, JSON.stringify(data,null,2)); fs.renameSync(tmp,file); }
const otpStore = new Map();

function json(res,status,body) {
  res.writeHead(status,{"Content-Type":"application/json; charset=utf-8","Access-Control-Allow-Origin":"*",
    "Access-Control-Allow-Headers":"Content-Type, Authorization","Access-Control-Allow-Methods":"GET, POST, PATCH, OPTIONS"});
  res.end(JSON.stringify(body));
}
function readBody(req) {
  return new Promise((resolve,reject)=>{
    let raw="";
    req.on("data",c=>{raw+=c;if(raw.length>2_000_000){reject(new Error("Payload too large"));req.destroy();}});
    req.on("end",()=>{try{resolve(JSON.parse(raw||"{}"));}catch{reject(new Error("Invalid JSON"));}});
    req.on("error",reject);
  });
}
function normalizePhone(phone){return String(phone||"").replace(/[^\d+]/g,"");}
function validPhone(phone){return /^\+[1-9]\d{7,14}$/.test(phone);}
function sign(payload){
  const body=Buffer.from(JSON.stringify(payload)).toString("base64url");
  return `${body}.${createHmac("sha256",JWT_SECRET).update(body).digest("base64url")}`;
}
function verifyToken(token){
  if(!token||!token.includes("."))return null;
  const [body,sig]=token.split(".");
  const expected=createHmac("sha256",JWT_SECRET).update(body).digest("base64url");
  const a=Buffer.from(sig||""),b=Buffer.from(expected);
  if(a.length!==b.length||!timingSafeEqual(a,b))return null;
  try{const p=JSON.parse(Buffer.from(body,"base64url").toString("utf8"));return p.exp>Date.now()?p:null;}catch{return null;}
}
function getUserFromToken(token){
  const payload=verifyToken(token);
  return payload ? read(USERS_FILE).find(u=>u.id===payload.sub) || null : null;
}
function authUser(req){return getUserFromToken(String(req.headers.authorization||"").replace(/^Bearer\s+/i,""));}
function publicUser(u){return {id:u.id,phone:u.phone,name:u.name||"",username:String(u.username||""),avatar:u.avatar||null,createdAt:u.createdAt};}
function normalizeUsername(value){return String(value||"").trim().replace(/^@/,"").toLowerCase();}
function validUsername(value){return /^[a-z][a-z0-9_]{4,31}$/.test(value);}
function tokenFor(u){return sign({sub:u.id,exp:Date.now()+30*24*60*60*1000});}
function pairKey(a,b){return [a,b].sort().join(":");}
function chatForUser(chat,userId){return chat.memberIds.includes(userId);}
function publicChat(chat,me){
  const otherId=chat.memberIds.find(id=>id!==me);
  const other=read(USERS_FILE).find(u=>u.id===otherId);
  const msgs=read(MESSAGES_FILE).filter(m=>m.chatId===chat.id);
  const last=msgs[msgs.length-1];
  return {id:chat.id, type:"private", user:other?publicUser(other):null,
    lastMessage:last?.text||"", lastTime:last?.time||"", updatedAt:chat.updatedAt};
}

const server=http.createServer(async(req,res)=>{
  if(req.method==="OPTIONS")return json(res,204,{});
  const url=new URL(req.url,`http://${req.headers.host||"localhost"}`);
  try{
    if(req.method==="GET"&&url.pathname==="/health")return json(res,200,{ok:true,service:"ayatogram-api"});
    if(req.method==="POST"&&url.pathname==="/auth/request-code"){
      const body=await readBody(req),phone=normalizePhone(body.phone);
      if(!validPhone(phone))return json(res,400,{error:"Введите номер в международном формате, например +46701234567"});
      const now=Date.now(),prev=otpStore.get(phone);
      if(prev&&now-prev.sentAt<30000)return json(res,429,{error:"Повторный код можно запросить через 30 секунд"});
      const code=String(randomInt(100000,1000000));
      otpStore.set(phone,{code,sentAt:now,expiresAt:now+300000,attempts:0});
      console.log(`[DEV OTP] ${phone}: ${code}`);
      return json(res,200,{ok:true,message:"Код создан. В режиме разработки он показан в консоли сервера.",...(isProduction?{}:{devCode:code})});
    }
    if(req.method==="POST"&&url.pathname==="/auth/verify-code"){
      const body=await readBody(req),phone=normalizePhone(body.phone),code=String(body.code||"").trim(),record=otpStore.get(phone);
      if(!record||record.expiresAt<Date.now()){otpStore.delete(phone);return json(res,400,{error:"Код истёк. Запросите новый."});}
      record.attempts++;
      if(record.attempts>5){otpStore.delete(phone);return json(res,429,{error:"Слишком много попыток. Запросите новый код."});}
      if(record.code!==code)return json(res,400,{error:"Неверный код подтверждения."});
      otpStore.delete(phone);
      const users=read(USERS_FILE);let user=users.find(u=>u.phone===phone);const isNew=!user;
      if(!user){user={id:randomBytes(16).toString("hex"),phone,name:"",username:"",avatar:null,createdAt:new Date().toISOString()};users.push(user);write(USERS_FILE,users);}
      return json(res,200,{ok:true,isNew,token:tokenFor(user),user:publicUser(user)});
    }
    if(req.method==="GET"&&url.pathname==="/me"){
      const user=authUser(req);if(!user)return json(res,401,{error:"Сессия недействительна."});
      return json(res,200,{user:publicUser(user)});
    }
    if(req.method==="PATCH"&&url.pathname==="/me"){
      const user=authUser(req);if(!user)return json(res,401,{error:"Сессия недействительна."});
      const body=await readBody(req),name=String(body.name??user.name).trim().slice(0,40);
      const avatar=body.avatar===undefined?user.avatar:body.avatar;
      const users=read(USERS_FILE),i=users.findIndex(u=>u.id===user.id);
      const username=body.username===undefined?String(users[i].username||""):normalizeUsername(body.username);
      if(username && !validUsername(username))return json(res,400,{error:"Юзернейм должен содержать 5–32 символа: латинские буквы, цифры и _. Первый символ — буква."});
      if(username && users.some((u,index)=>index!==i&&normalizeUsername(u.username)===username))return json(res,409,{error:"Этот юзернейм уже занят."});
      if(body.avatar!==undefined&&avatar!==null&&(typeof avatar!=="string"||!/^data:image\/(png|jpeg|webp);base64,/.test(avatar)||avatar.length>1500000))
        return json(res,400,{error:"Недопустимое изображение или слишком большой файл."});
      users[i]={...users[i],name,username,avatar};write(USERS_FILE,users);
      return json(res,200,{ok:true,user:publicUser(users[i])});
    }

    const usernameMatch=url.pathname.match(/^\/users\/username\/([a-zA-Z0-9_]+)$/);
    if(req.method==="GET"&&usernameMatch){
      const username=normalizeUsername(usernameMatch[1]);
      const found=read(USERS_FILE).find(u=>normalizeUsername(u.username)===username);
      if(!found)return json(res,404,{error:"Пользователь не найден."});
      return json(res,200,{user:publicUser(found)});
    }
    const me=authUser(req);
    if(url.pathname.startsWith("/users")||url.pathname.startsWith("/chats")){
      if(!me)return json(res,401,{error:"Требуется авторизация."});
    }
    if(req.method==="GET"&&url.pathname==="/users/search"){
      const rawQuery=(url.searchParams.get("q")||"").trim();
      const q=normalizePhone(rawQuery).toLowerCase();
      const usernameQuery=normalizeUsername(rawQuery);
      const nameQuery=rawQuery.replace(/^@/,"").toLowerCase();
      const users=read(USERS_FILE).filter(u=>u.id!==me.id&&(
        (q && u.phone.includes(q)) ||
        (rawQuery.length>=2 && (u.name||"").toLowerCase().includes(nameQuery)) ||
        (usernameQuery.length>=2 && normalizeUsername(u.username).includes(usernameQuery))
      )).slice(0,50);
      return json(res,200,{users:users.map(publicUser)});
    }
    if(req.method==="GET"&&url.pathname==="/chats"){
      const chats=read(CHATS_FILE).filter(c=>chatForUser(c,me.id)).map(c=>publicChat(c,me.id))
        .sort((a,b)=>(b.updatedAt||"").localeCompare(a.updatedAt||""));
      return json(res,200,{chats});
    }
    if(req.method==="POST"&&url.pathname==="/chats"){
      const body=await readBody(req),targetId=String(body.userId||"");
      if(targetId===me.id)return json(res,400,{error:"Нельзя создать чат с самим собой."});
      const target=read(USERS_FILE).find(u=>u.id===targetId);
      if(!target)return json(res,404,{error:"Пользователь не найден."});
      const chats=read(CHATS_FILE),key=pairKey(me.id,targetId);
      let chat=chats.find(c=>c.pairKey===key);
      if(!chat){chat={id:randomBytes(16).toString("hex"),type:"private",memberIds:[me.id,targetId],pairKey:key,createdAt:new Date().toISOString(),updatedAt:new Date().toISOString()};chats.push(chat);write(CHATS_FILE,chats);}
      return json(res,200,{chat:publicChat(chat,me.id)});
    }
    const historyMatch=url.pathname.match(/^\/chats\/([a-f0-9]+)\/messages$/);
    if(req.method==="GET"&&historyMatch){
      const chat=read(CHATS_FILE).find(c=>c.id===historyMatch[1]&&chatForUser(c,me.id));
      if(!chat)return json(res,404,{error:"Чат не найден."});
      const messages=read(MESSAGES_FILE).filter(m=>m.chatId===chat.id);
      return json(res,200,{messages});
    }
    return json(res,404,{error:"Not found"});
  }catch(e){console.error(e);return json(res,500,{error:"Ошибка сервера."});}
});

const wss=new WebSocketServer({noServer:true});
server.on("upgrade",(req,socket,head)=>{
  const url=new URL(req.url,`http://${req.headers.host||"localhost"}`);
  const user=getUserFromToken(url.searchParams.get("token"));
  const chatId=url.searchParams.get("chatId");
  const chat=read(CHATS_FILE).find(c=>c.id===chatId&&user&&chatForUser(c,user.id));
  if(!user||!chat){socket.write("HTTP/1.1 401 Unauthorized\r\n\r\n");socket.destroy();return;}
  wss.handleUpgrade(req,socket,head,ws=>{ws.userId=user.id;ws.chatId=chat.id;wss.emit("connection",ws,req);});
});
wss.on("connection",ws=>{
  const history=read(MESSAGES_FILE).filter(m=>m.chatId===ws.chatId);
  ws.send(JSON.stringify({type:"history",messages:history}));
  ws.on("message",raw=>{
    let input;try{input=JSON.parse(raw.toString());}catch{return;}
    if(input.type!=="message")return;
    const text=String(input.text||"").trim().slice(0,4000);if(!text)return;
    const chat=read(CHATS_FILE).find(c=>c.id===ws.chatId&&chatForUser(c,ws.userId));if(!chat)return;
    const users=read(USERS_FILE),sender=users.find(u=>u.id===ws.userId);
    const msg={id:randomBytes(12).toString("hex"),chatId:ws.chatId,senderId:ws.userId,
      user:sender?.name||sender?.phone||"Пользователь",text,time:new Date().toLocaleTimeString("ru-RU",{hour:"2-digit",minute:"2-digit"}),
      createdAt:new Date().toISOString()};
    const messages=read(MESSAGES_FILE);messages.push(msg);write(MESSAGES_FILE,messages);
    chat.updatedAt=msg.createdAt;write(CHATS_FILE,read(CHATS_FILE).map(c=>c.id===chat.id?chat:c));
    const data=JSON.stringify({type:"message",message:msg});
    for(const client of wss.clients)if(client.readyState===1&&client.chatId===chat.id)client.send(data);
  });
});
server.listen(PORT,"0.0.0.0",()=>{console.log(`Ayatogram API + private chat server on :${PORT}`);if(!isProduction)console.log("Development OTP mode: codes are printed here.");});
