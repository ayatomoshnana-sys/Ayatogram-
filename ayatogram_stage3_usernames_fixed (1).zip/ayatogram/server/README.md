# Ayatogram Android backend

Requires Node.js 20+.

```bash
cd server
npm install
JWT_SECRET="replace-with-a-long-random-secret" npm start
```

API supports development OTP, profiles, user search, private chat creation, chat lists, message history and authenticated per-chat WebSocket delivery.
- `POST /auth/request-code`, `POST /auth/verify-code`
- `GET/PATCH /me`
- `GET /users/search?q=...`
- `GET /chats`, `POST /chats` with `{ "userId": "..." }`
- `GET /chats/:id/messages`
- WebSocket upgrade: `/?token=...&chatId=...`

JSON files in `DATA_DIR` persist users, chats and messages across restarts. OTPs remain development-only: no SMS is sent. Use HTTPS/WSS, strong secret management, a real SMS provider, database, rate limiting and security review before any public production deployment.
