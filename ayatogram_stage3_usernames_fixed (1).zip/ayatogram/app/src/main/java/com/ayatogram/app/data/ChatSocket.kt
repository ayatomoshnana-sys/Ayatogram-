package com.ayatogram.app.data

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okhttp3.Response
import org.json.JSONObject
import java.util.concurrent.TimeUnit

data class NetworkMessage(val id:String,val user:String,val text:String,val time:String,val senderId:String="")

class ChatSocket {
    private val client=OkHttpClient.Builder().pingInterval(25,TimeUnit.SECONDS).build()
    private var socket:WebSocket?=null
    private val _messages=MutableStateFlow<List<NetworkMessage>>(emptyList())
    val messages:StateFlow<List<NetworkMessage>> = _messages
    private val _status=MutableStateFlow("Не подключено")
    val status:StateFlow<String> = _status

    fun connect(url:String){
        disconnect();_status.value="Подключение…"
        socket=client.newWebSocket(Request.Builder().url(url).build(),object:WebSocketListener(){
            override fun onOpen(webSocket:WebSocket,response:Response){_status.value="Подключено"}
            override fun onMessage(webSocket:WebSocket,text:String){
                try{
                    val j=JSONObject(text)
                    if(j.optString("type")=="history"){
                        val a=j.optJSONArray("messages");val list=mutableListOf<NetworkMessage>()
                        if(a!=null)for(i in 0 until a.length())list.add(parse(a.getJSONObject(i)))
                        _messages.value=list
                    }else if(j.optString("type")=="message"){
                        val m=parse(j.getJSONObject("message"));_messages.value=_messages.value.filterNot{it.id==m.id}+m
                    }
                }catch(_:Exception){}
            }
            override fun onFailure(webSocket:WebSocket,t:Throwable,response:Response?){_status.value="Ошибка: ${t.message?:"нет соединения"}"}
            override fun onClosed(webSocket:WebSocket,code:Int,reason:String){_status.value="Отключено"}
        })
    }
    fun send(text:String){if(text.isNotBlank())socket?.send(JSONObject().put("type","message").put("text",text.trim()).toString())}
    fun disconnect(){socket?.close(1000,"screen closed");socket=null}
    private fun parse(j:JSONObject)=NetworkMessage(j.optString("id"),j.optString("user"),j.optString("text"),j.optString("time"),j.optString("senderId"))
}
