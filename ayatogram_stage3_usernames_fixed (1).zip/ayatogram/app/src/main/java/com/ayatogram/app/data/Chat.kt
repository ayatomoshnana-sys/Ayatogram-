package com.ayatogram.app.data

data class Chat(
    val id: String,
    val title: String,
    val lastMessage: String,
    val time: String,
    val unreadCount: Int = 0,
    val isVerified: Boolean = false,
    val isOnline: Boolean = false
)

object DemoChats {
    val items = listOf(
        Chat("1", "Ayatogram", "Добро пожаловать! Здесь будет ваша переписка.", "сейчас", isVerified = true),
        Chat("2", "Избранное", "Заметки и сохранённые сообщения", "Вчера"),
        Chat("3", "Команда", "Обсудим обновление проекта", "Пн", 3, isOnline = true),
        Chat("4", "Александр", "Отправил фотографию", "Вс", 0, isOnline = true),
        Chat("5", "Новости", "Новые возможности уже скоро", "Сб", 12, isVerified = true)
    )
}
