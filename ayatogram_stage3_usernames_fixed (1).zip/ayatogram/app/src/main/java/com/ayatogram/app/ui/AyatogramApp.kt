package com.ayatogram.app.ui

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ayatogram.app.data.*
import kotlinx.coroutines.launch

private val Blue=Color(0xFF229ED9)

@Composable
fun AyatogramApp(){
    val context=LocalContext.current
    val api=remember{AuthApi(context)}
    var user by remember{mutableStateOf<AuthUser?>(null)}
    var checking by remember{mutableStateOf(api.token!=null)}
    LaunchedEffect(Unit){if(api.token!=null)try{user=api.me()}catch(_:Exception){api.logout()};checking=false}
    if(checking)Box(Modifier.fillMaxSize(),contentAlignment=Alignment.Center){CircularProgressIndicator(color=Blue)}
    else if(user==null)AuthScreen(api){user=it}
    else MainMessenger(api,user!!){api.logout();user=null}
}

@Composable
private fun AuthScreen(api:AuthApi,onAuthenticated:(AuthUser)->Unit){
    var phone by remember{mutableStateOf("")};var code by remember{mutableStateOf("")}
    var server by remember{mutableStateOf(api.baseUrl)};var sent by remember{mutableStateOf(false)}
    var devCode by remember{mutableStateOf("")};var busy by remember{mutableStateOf(false)};var error by remember{mutableStateOf("")}
    val scope=rememberCoroutineScope()
    Column(Modifier.fillMaxSize().padding(24.dp),verticalArrangement=Arrangement.Center){
        Icon(Icons.Default.Send,null,tint=Blue,modifier=Modifier.size(54.dp))
        Spacer(Modifier.height(18.dp));Text("Добро пожаловать в Ayatogram",fontSize=25.sp,fontWeight=FontWeight.Bold)
        Text("Войдите или создайте аккаунт по номеру телефона.",color=MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(20.dp))
        OutlinedTextField(server,{server=it;api.baseUrl=it},Modifier.fillMaxWidth(),label={Text("Адрес API-сервера")},singleLine=true)
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(phone,{phone=it},Modifier.fillMaxWidth(),label={Text("Номер телефона")},placeholder={Text("+46701234567")},singleLine=true)
        if(sent){Spacer(Modifier.height(8.dp));OutlinedTextField(code,{code=it.filter(Char::isDigit).take(6)},Modifier.fillMaxWidth(),label={Text("Код подтверждения")},singleLine=true)
            if(devCode.isNotBlank())Text("Тестовый код: $devCode",color=Blue)}
        if(error.isNotBlank())Text(error,color=MaterialTheme.colorScheme.error)
        Spacer(Modifier.height(14.dp))
        Button(onClick={scope.launch{busy=true;error="";try{if(!sent){devCode=api.requestCode(phone);sent=true}else onAuthenticated(api.verifyCode(phone,code).user)}catch(e:Exception){error=e.message?:"Ошибка"}finally{busy=false}}},Modifier.fillMaxWidth(),enabled=!busy&&phone.isNotBlank()&&(!sent||code.length==6)){
            if(busy)CircularProgressIndicator(Modifier.size(18.dp),color=Color.White)else Text(if(sent)"Подтвердить и войти" else "Получить код")}
        Text("Для телефона укажите IP компьютера в одной Wi-Fi сети или публичный HTTPS-адрес сервера.",fontSize=11.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun MainMessenger(api:AuthApi,initial:AuthUser,onLogout:()->Unit){
    var user by remember{mutableStateOf(initial)};var tab by remember{mutableIntStateOf(0)}
    var selected by remember{mutableStateOf<PrivateChat?>(null)}
    var chats by remember{mutableStateOf<List<PrivateChat>>(emptyList())}
    var loading by remember{mutableStateOf(false)};var loadError by remember{mutableStateOf("")}
    val scope=rememberCoroutineScope()
    suspend fun refresh(){loading=true;try{chats=api.getChats();loadError=""}catch(e:Exception){loadError=e.message?:"Не удалось загрузить чаты"};loading=false}
    LaunchedEffect(Unit){refresh()}
    if(selected!=null)PrivateChatScreen(api,user,selected!!,{selected=null;scope.launch{refresh()}})
    else Scaffold(topBar={TopAppBar(title={Column{Text("Ayatogram",fontWeight=FontWeight.Bold);Text("мессенджер",fontSize=11.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)}},
        actions={IconButton(onClick={tab=3}){Avatar(user.avatar,user.name,Modifier.size(34.dp))};IconButton(onClick={scope.launch{refresh()}}){Icon(Icons.Default.Refresh,"Обновить")}})},
        bottomBar={NavigationBar{
            NavigationBarItem(tab==0,{tab=0},icon={Icon(Icons.Default.Chat,null)},label={Text("Чаты")})
            NavigationBarItem(tab==1,{tab=1},icon={Icon(Icons.Default.People,null)},label={Text("Контакты")})
            NavigationBarItem(tab==2,{tab=2},icon={Icon(Icons.Default.Campaign,null)},label={Text("Каналы")})
            NavigationBarItem(tab==3,{tab=3},icon={Icon(Icons.Default.Person,null)},label={Text("Профиль")})
        }}){padding->
        when(tab){
            0->ChatsScreen(Modifier.padding(padding),chats,loading,loadError,{selected=it},{scope.launch{refresh()}})
            1->ContactsScreen(Modifier.padding(padding),api){chat->selected=chat;scope.launch{refresh()}}
            3->ProfileScreen(api,user,{user=it},onLogout,Modifier.padding(padding))
            else->PlaceholderTab(Modifier.padding(padding),"Каналы")
        }
    }
}

@Composable
private fun ChatsScreen(modifier:Modifier,chats:List<PrivateChat>,loading:Boolean,error:String,onOpen:(PrivateChat)->Unit,onRefresh:()->Unit){
    Column(modifier.fillMaxSize()){
        if(error.isNotBlank())Text(error,color=MaterialTheme.colorScheme.error,modifier=Modifier.padding(12.dp))
        if(loading)LinearProgressIndicator(Modifier.fillMaxWidth(),color=Blue)
        if(chats.isEmpty()&&!loading)Box(Modifier.fillMaxSize(),contentAlignment=Alignment.Center){Column(horizontalAlignment=Alignment.CenterHorizontally){
            Icon(Icons.Default.ChatBubbleOutline,null,tint=Blue,modifier=Modifier.size(44.dp));Text("Пока нет личных чатов")
            Text("Откройте «Контакты», чтобы найти собеседника.",fontSize=12.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)
            OutlinedButton(onClick=onRefresh){Text("Обновить")}
        }}else LazyColumn{items(chats,key={it.id}){chat->Row(Modifier.fillMaxWidth().clickable{onOpen(chat)}.padding(14.dp),verticalAlignment=Alignment.CenterVertically){
            Avatar(chat.user.avatar,chat.user.name.ifBlank{chat.user.phone},Modifier.size(52.dp));Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)){Text(chat.user.name.ifBlank{chat.user.phone},fontWeight=FontWeight.SemiBold);Text(chat.lastMessage.ifBlank{"Начните переписку"},maxLines=1,fontSize=13.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)}
            Text(chat.lastTime,fontSize=11.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)
        };HorizontalDivider()}}
    }
}

@Composable
private fun ContactsScreen(modifier:Modifier,api:AuthApi,onOpen:(PrivateChat)->Unit){
    var query by remember{mutableStateOf("")};var users by remember{mutableStateOf<List<AuthUser>>(emptyList())}
    var busy by remember{mutableStateOf(false)};var error by remember{mutableStateOf("")}
    val scope=rememberCoroutineScope()
    Column(modifier.fillMaxSize().padding(16.dp)){
        Text("Найти пользователя",fontSize=23.sp,fontWeight=FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(query,{query=it},Modifier.fillMaxWidth(),singleLine=true,
            label={Text("@username, телефон или имя")},placeholder={Text("@ayato или +46701234567")},
            trailingIcon={IconButton(onClick={scope.launch{busy=true;try{users=api.searchUsers(query);error=""}catch(e:Exception){error=e.message?:"Ошибка"};busy=false}}){Icon(Icons.Default.Search,"Искать")}})
        Spacer(Modifier.height(8.dp))
        Button(onClick={scope.launch{busy=true;try{users=api.searchUsers(query);error=""}catch(e:Exception){error=e.message?:"Ошибка"};busy=false}},Modifier.fillMaxWidth(),enabled=query.trim().length>=2&&!busy){Text(if(busy)"Поиск…" else "Найти")}
        if(error.isNotBlank())Text(error,color=MaterialTheme.colorScheme.error)
        if(users.isEmpty()&&!busy)Text("Введите @username, номер телефона или имя, чтобы найти пользователя.",fontSize=13.sp,color=MaterialTheme.colorScheme.onSurfaceVariant,modifier=Modifier.padding(top=12.dp))
        LazyColumn{items(users,key={it.id}){u->Row(Modifier.fillMaxWidth().clickable{
            scope.launch{busy=true;try{onOpen(api.createChat(u.id));error=""}catch(e:Exception){error=e.message?:"Не удалось создать чат"};busy=false}
        }.padding(vertical=12.dp),verticalAlignment=Alignment.CenterVertically){
            Avatar(u.avatar,u.name.ifBlank{u.phone},Modifier.size(48.dp));Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)){Text(u.name.ifBlank{"Пользователь"},fontWeight=FontWeight.SemiBold);Text(if(u.username.isNotBlank())"@${u.username}" else u.phone,fontSize=12.sp,color=MaterialTheme.colorScheme.onSurfaceVariant)}
            Icon(Icons.Default.Message,contentDescription=null,tint=Blue)
        };HorizontalDivider()}}
    }
}

@Composable
private fun Avatar(data:String?,label:String,modifier:Modifier=Modifier){
    val bitmap=remember(data){try{if(data.isNullOrBlank())null else{val bytes=Base64.decode(data.substringAfter(","),Base64.DEFAULT);BitmapFactory.decodeByteArray(bytes,0,bytes.size)}}catch(_:Exception){null}}
    Box(modifier.clip(CircleShape).background(Blue.copy(alpha=.15f)),contentAlignment=Alignment.Center){
        if(bitmap!=null)Image(bitmap.asImageBitmap(),null,modifier=Modifier.fillMaxSize())else Text(label.firstOrNull()?.uppercase()?:"?",color=Blue,fontWeight=FontWeight.Bold)
    }
}

@Composable
private fun ProfileScreen(api:AuthApi,user:AuthUser,onUpdated:(AuthUser)->Unit,onLogout:()->Unit,modifier:Modifier){
    val context=LocalContext.current;val scope=rememberCoroutineScope()
    var name by remember(user.name){mutableStateOf(user.name)};var username by remember(user.username){mutableStateOf(user.username)};var avatar by remember(user.avatar){mutableStateOf(user.avatar)}
    var busy by remember{mutableStateOf(false)};var error by remember{mutableStateOf("")}
    val picker=rememberLauncherForActivityResult(ActivityResultContracts.GetContent()){uri->if(uri!=null)try{
        context.contentResolver.openInputStream(uri)?.use{stream->val bytes=stream.readBytes();if(bytes.size>900000)error="Изображение слишком большое" else{
            val bmp=BitmapFactory.decodeByteArray(bytes,0,bytes.size);if(bmp!=null){val scaled=Bitmap.createScaledBitmap(bmp,256,256,true);val out=java.io.ByteArrayOutputStream();scaled.compress(Bitmap.CompressFormat.JPEG,82,out);avatar="data:image/jpeg;base64,"+Base64.encodeToString(out.toByteArray(),Base64.NO_WRAP)}
        }}
    }catch(_:Exception){error="Не удалось открыть изображение"}}
    Column(modifier.fillMaxSize().padding(20.dp)){
        Text("Мой профиль",fontSize=24.sp,fontWeight=FontWeight.Bold);Spacer(Modifier.height(20.dp))
        Row(verticalAlignment=Alignment.CenterVertically){Avatar(avatar,name,Modifier.size(82.dp));Spacer(Modifier.width(14.dp));OutlinedButton(onClick={picker.launch("image/*")}){Icon(Icons.Default.PhotoCamera,null);Text("Изменить фото")}}
        Spacer(Modifier.height(20.dp));OutlinedTextField(name,{name=it.take(40)},Modifier.fillMaxWidth(),label={Text("Имя")},singleLine=true)
        Spacer(Modifier.height(8.dp));OutlinedTextField(username,{username=it.removePrefix("@").lowercase().filter{ch->ch in 'a'..'z'||ch in '0'..'9'||ch=='_'}.take(32)},Modifier.fillMaxWidth(),label={Text("Юзернейм")},placeholder={Text("ayato")},leadingIcon={Text("@")},singleLine=true, supportingText={Text("5–32 символа: латинские буквы, цифры и _. Можно оставить пустым.")})
        Spacer(Modifier.height(8.dp));OutlinedTextField(user.phone,{},Modifier.fillMaxWidth(),label={Text("Телефон")},readOnly=true)
        if(error.isNotBlank())Text(error,color=MaterialTheme.colorScheme.error)
        Spacer(Modifier.height(14.dp));Button(onClick={scope.launch{busy=true;try{onUpdated(api.updateProfile(name,username,avatar))}catch(e:Exception){error=e.message?:"Ошибка"};busy=false}},Modifier.fillMaxWidth(),enabled=!busy&&name.isNotBlank()){Text("Сохранить профиль")}
        OutlinedButton(onClick=onLogout,Modifier.fillMaxWidth()){Icon(Icons.Default.Logout,null);Text("Выйти из аккаунта")}
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun PrivateChatScreen(api:AuthApi,me:AuthUser,chat:PrivateChat,onBack:()->Unit){
    val socket=remember(chat.id){ChatSocket()};val messages by socket.messages.collectAsState();val status by socket.status.collectAsState()
    var text by remember{mutableStateOf("")};val listState=androidx.compose.foundation.lazy.rememberLazyListState()
    DisposableEffect(chat.id){socket.connect(api.websocketUrl(chat.id));onDispose{socket.disconnect()}}
    Scaffold(topBar={TopAppBar(navigationIcon={IconButton(onClick=onBack){Icon(Icons.Default.ArrowBack,"Назад")}},
        title={Row(verticalAlignment=Alignment.CenterVertically){Avatar(chat.user.avatar,chat.user.name,Modifier.size(38.dp));Spacer(Modifier.width(10.dp));Column{
            Text(chat.user.name.ifBlank{chat.user.phone},fontWeight=FontWeight.SemiBold);Text(status,fontSize=11.sp,color=if(status=="Подключено")Color(0xFF269B68) else MaterialTheme.colorScheme.onSurfaceVariant)
        }}})},
        bottomBar={Row(Modifier.fillMaxWidth().navigationBarsPadding().imePadding().padding(8.dp),verticalAlignment=Alignment.CenterVertically){
            OutlinedTextField(text,{text=it},Modifier.weight(1f),placeholder={Text("Сообщение")},shape=RoundedCornerShape(26.dp),maxLines=4)
            IconButton(onClick={socket.send(text);text=""},enabled=text.isNotBlank()&&status=="Подключено"){Icon(Icons.Default.Send,"Отправить",tint=Blue)}
        }}){padding->
        if(messages.isEmpty())Box(Modifier.fillMaxSize().padding(padding),contentAlignment=Alignment.Center){Text(if(status=="Подключено")"Начните переписку" else status,color=MaterialTheme.colorScheme.onSurfaceVariant)}
        else LazyColumn(state=listState,modifier=Modifier.fillMaxSize().padding(padding).padding(horizontal=10.dp),contentPadding=PaddingValues(vertical=10.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
            items(messages,key={it.id}){m->val own=m.senderId==me.id
                Row(Modifier.fillMaxWidth(),horizontalArrangement=if(own)Arrangement.End else Arrangement.Start){
                    Column(Modifier.widthIn(max=300.dp).background(if(own)Color(0xFFDDF3FF) else MaterialTheme.colorScheme.surfaceVariant,RoundedCornerShape(16.dp)).padding(12.dp)){
                        if(!own)Text(m.user,color=Blue,fontSize=12.sp,fontWeight=FontWeight.SemiBold)
                        Text(m.text,color=Color(0xFF17212B));Text(m.time,Modifier.align(Alignment.End),fontSize=10.sp,color=Color(0xFF607D8B))
                    }
                }
            }
        }
        LaunchedEffect(messages.size){if(messages.isNotEmpty())listState.animateScrollToItem(messages.lastIndex)}
    }
}

@Composable
private fun PlaceholderTab(modifier:Modifier,title:String){Box(modifier.fillMaxSize(),contentAlignment=Alignment.Center){Column(horizontalAlignment=Alignment.CenterHorizontally){
    Icon(Icons.Default.Construction,null,tint=Blue,modifier=Modifier.size(42.dp));Text(title,fontSize=20.sp,fontWeight=FontWeight.Bold);Text("Раздел будет реализован на следующем этапе")
}}}
