package com.ayatogram.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.ayatogram.app.ui.AyatogramApp
import com.ayatogram.app.ui.theme.AyatogramTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            AyatogramTheme { AyatogramApp() }
        }
    }
}
