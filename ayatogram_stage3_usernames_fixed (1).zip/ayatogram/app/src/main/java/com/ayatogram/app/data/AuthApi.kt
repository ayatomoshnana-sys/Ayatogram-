package com.ayatogram.app.data

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import org.json.JSONArray
import java.io.IOException
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

data class AuthUser(val id:String,val phone:String,val name:String,val username:String,val avatar:String?)
data class AuthResult(val token:String,val user:AuthUser,val isNew:Boolean)
data class PrivateChat(val id:String,val user:AuthUser,val lastMessage:String,val lastTime:String)
data class StoredMessage(val id:String,val chatId:String,val senderId:String,val user:String,val text:String,val time:String)

class AuthApi(private val context:Context) {
    private val client=OkHttpClient.Builder().connectTimeout(15,TimeUnit.SECONDS).readTimeout(20,TimeUnit.SECONDS).build()
    private val prefs=context.getSharedPreferences("ayatogram_session",Context.MODE_PRIVATE)
    var baseUrl:String
        get()=prefs.getString("api_base_url","http://10.0.2.2:8080")?:"http://10.0.2.2:8080"
        set(value){prefs.edit().putString("api_base_url",value.trim().trimEnd('/')).apply()}
    val token:String? get()=prefs.getString("token",null)
    fun saveToken(value:String){prefs.edit().putString("token",value).apply()}
    fun logout(){prefs.edit().remove("token").apply()}

    suspend fun requestCode(phone:String):String=request("POST","/auth/request-code",JSONObject().put("phone",phone)).let{
        it.optString("devCode").ifBlank{it.optString("message")}
    }
    suspend fun verifyCode(phone:String,code:String):AuthResult{
        val j=request("POST","/auth/verify-code",JSONObject().put("phone",phone).put("code",code))
        val user=parseUser(j.getJSONObject("user"));val token=j.getString("token");saveToken(token)
        return AuthResult(token,user,j.optBoolean("isNew"))
    }
    suspend fun me():AuthUser=parseUser(request("GET","/me",auth=true).getJSONObject("user"))
    suspend fun updateProfile(name:String,username:String,avatar:String?):AuthUser{
        val b=JSONObject().put("name",name).put("username",username);if(avatar!=null)b.put("avatar",avatar)
        return parseUser(request("PATCH","/me",b,true).getJSONObject("user"))
    }
    suspend fun searchUsers(query:String):List<AuthUser>{
        val q=URLEncoder.encode(query,"UTF-8")
        val arr=request("GET","/users/search?q=$q",auth=true).optJSONArray("users")?:JSONArray()
        return (0 until arr.length()).map{parseUser(arr.getJSONObject(it))}
    }
    suspend fun createChat(userId:String):PrivateChat{
        val j=request("POST","/chats",JSONObject().put("userId",userId),true).getJSONObject("chat")
        return parseChat(j)
    }
    suspend fun getChats():List<PrivateChat>{
        val arr=request("GET","/chats",auth=true).optJSONArray("chats")?:JSONArray()
        return (0 until arr.length()).map{parseChat(arr.getJSONObject(it))}
    }
    suspend fun getMessages(chatId:String):List<StoredMessage>{
        val arr=request("GET","/chats/$chatId/messages",auth=true).optJSONArray("messages")?:JSONArray()
        return (0 until arr.length()).map{parseMessage(arr.getJSONObject(it))}
    }
    fun websocketUrl(chatId:String):String{
        val base=baseUrl.replaceFirst("https://","wss://").replaceFirst("http://","ws://")
        return "$base?token=${token.orEmpty()}&chatId=$chatId"
    }
    private suspend fun request(method:String,path:String,body:JSONObject?=null,auth:Boolean=false):JSONObject=withContext(Dispatchers.IO){
        val b=Request.Builder().url(baseUrl+path).header("Accept","application/json")
        if(auth){val t=token?:throw IOException("Нет активной сессии");b.header("Authorization","Bearer $t")}
        if(method=="GET")b.get() else b.method(method,(body?:JSONObject()).toString().toRequestBody("application/json; charset=utf-8".toMediaType()))
        client.newCall(b.build()).execute().use{r->
            val raw=r.body?.string().orEmpty();val j=try{JSONObject(raw)}catch(_:Exception){JSONObject()}
            if(!r.isSuccessful)throw IOException(j.optString("error").ifBlank{"HTTP ${r.code}"})
            j
        }
    }
    private fun parseUser(j:JSONObject)=AuthUser(j.optString("id"),j.optString("phone"),j.optString("name"),j.optString("username"),if(j.isNull("avatar"))null else j.optString("avatar"))
    private fun parseChat(j:JSONObject):PrivateChat{
        val u=j.optJSONObject("user")?:JSONObject()
        return PrivateChat(j.optString("id"),parseUser(u),j.optString("lastMessage"),j.optString("lastTime"))
    }
    private fun parseMessage(j:JSONObject)=StoredMessage(j.optString("id"),j.optString("chatId"),j.optString("senderId"),j.optString("user"),j.optString("text"),j.optString("time"))
}
