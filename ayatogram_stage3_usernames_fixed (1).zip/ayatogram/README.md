# Ayatogram — Android starter

Стартовый Android-проект на Kotlin + Jetpack Compose. Это UI-прототип, не готовый сетевой мессенджер: демо-чаты локальные, отправка пока не подключена к серверу.

## Открыть и собрать
1. Установить Android Studio (JDK 17).
2. Открыть папку `ayatogram` как Gradle project.
3. Дождаться синхронизации Gradle и установить Android SDK Platform 35.
4. Для APK: **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Debug APK появится в `app/build/outputs/apk/debug/app-debug.apk`.

## Архитектура целевого продукта

### Android-клиент
- `ui/`: Compose-экраны, навигация, тема, компоненты.
- `domain/`: use cases и бизнес-правила (следующий этап).
- `data/`: репозитории, DTO, локальная БД и сетевые источники (следующий этап).
- `core/`: авторизация, криптография, загрузки, уведомления.

### Backend (отдельный сервис, следующий этап)
- API Gateway: REST для профиля, контактов, чатов и настроек.
- Realtime Gateway: WebSocket для доставки сообщений, статусов и typing.
- Auth: телефон/email, одноразовые коды, refresh tokens, управление сессиями.
- Chat Service: личные/групповые чаты, роли, история, реакции, редактирование и удаление.
- Media Service: загрузка файлов, проверка MIME/размера, объектное хранилище, CDN.
- Notification Service: push через FCM.
- Calls: signaling + WebRTC SFU для групповых звонков.
- Search: поиск по чатам/сообщениям с контролем доступа.
- PostgreSQL: пользователи, устройства, чаты, участники, сообщения, реакции.
- Redis: presence, rate limits, кэш и временные состояния.
- Object storage: медиа и документы.

### Безопасность — обязательные решения до запуска
- TLS везде, короткоживущие access tokens и ротация refresh tokens.
- Защита от перебора кодов, rate limiting, управление активными сессиями.
- Сквозное шифрование — отдельный проверенный протокол и независимый аудит; не изобретать криптографию самостоятельно.
- Секретные чаты не хранить в открытом виде на сервере.
- Резервное копирование, мониторинг, аудит доступа и план реагирования на инциденты.

## Этапы разработки
1. Продуктовый фундамент: регистрация, профиль, список чатов, личные сообщения, доставка и синхронизация.
2. Группы, каналы, файлы, голосовые сообщения, реакции, поиск.
3. Push, несколько устройств, архив/папки, настройки приватности.
4. Звонки, боты, истории, секретные чаты и дополнительные функции.
5. Нагрузочное тестирование, аудит безопасности, релиз.

## Текущий статус
- Создана базовая Android-структура.
- Реализован визуальный каркас списка чатов и экрана диалога.
- Контакты, каналы, настройки и сетевой обмен пока являются заглушками.


## Сборка APK через GitHub Actions
В проект добавлен workflow `.github/workflows/build-apk.yml`. После загрузки проекта в GitHub:
1. Откройте вкладку **Actions**.
2. Запустите **Build Ayatogram APK** (или отправьте commit в `main`).
3. После успешной сборки скачайте артефакт `ayatogram-debug-apk`.


## Сетевая переписка (prototype)
Добавлен WebSocket-клиент Android и Node.js сервер в `server/`.
- Запустить сервер: `cd server && npm install && npm start`.
- Эмулятор Android: в общем чате оставить `ws://10.0.2.2:8080`.
- Реальный Android: указать LAN IP компьютера, например `ws://192.168.1.10:8080`, когда оба устройства в одной Wi-Fi сети.
- Для интернета нужен публично размещённый сервер с TLS и адресом `wss://...`.

Текущая версия демонстрирует общий чат: сообщения рассылаются всем подключённым клиентам, последние 200 хранятся в памяти сервера. Это не production-ready: пока нет аккаунтов, личных комнат, БД, TLS-настройки, сквозного шифрования и защиты от злоупотреблений.


## Android account and profile (stage 1)
- Phone-number registration/login flow using one-time verification code.
- Profile name and avatar editing, with session token persisted on device.
- API stores user records in `server/data/users.json`.
- Development OTP is displayed by the app and printed by server. No SMS is sent yet; production SMS provider integration is required.
- Start backend with `cd server && npm install && npm start`; set `JWT_SECRET` to a long random secret.
- Android emulator API address: `http://10.0.2.2:8080`. For a physical phone, use the computer's LAN IP or a public HTTPS endpoint.


## Stage 2 — private conversations and contacts
- Search registered accounts by phone number or display name.
- Create or reuse a one-to-one private chat.
- List the signed-in user's private conversations.
- WebSocket connections are authenticated with the user's session token and scoped to a chat.
- Message history is persisted in JSON files on the server (`users.json`, `chats.json`, `messages.json`).
- This is still a prototype backend; JSON storage should be replaced with PostgreSQL before public use.

## Юзернеймы (этап 3)

- В профиле можно задать уникальный `@username` или оставить поле пустым.
- Допустимы 5–32 символа: латинские буквы, цифры и `_`; первый символ — буква.
- Юзернеймы нормализуются в нижний регистр и проверяются на уникальность без учёта регистра.
- Поиск контактов понимает `@username`, имя и номер телефона.
- Для серверного разрешения имени доступен `GET /users/username/:username`.
